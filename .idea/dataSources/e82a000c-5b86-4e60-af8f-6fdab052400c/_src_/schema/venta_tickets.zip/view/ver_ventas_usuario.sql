CREATE VIEW ver_ventas_usuario AS
  SELECT
    `v`.`ven_id`             AS `ven_id`,
    `v`.`ven_pago_realizado` AS `ven_pago_realizado`,
    `s`.`sec_id`             AS `sec_id`,
    `s`.`sec_nombre`         AS `sec_nombre`,
    `s`.`sec_costo`          AS `sec_costo`,
    `e`.`eve_id`             AS `eve_id`,
    `e`.`eve_nombre`         AS `eve_nombre`,
    `e`.`eve_fecha`          AS `eve_fecha`,
    `e`.`eve_hora`           AS `eve_hora`,
    `c`.`cat_nombre`         AS `cat_nombre`,
    `u`.`usu_id`             AS `usu_id`,
    `u`.`usu_correo`         AS `usu_correo`
  FROM ((((`venta_tickets`.`ventas` `v`
    JOIN `venta_tickets`.`secciones` `s`) JOIN `venta_tickets`.`usuarios` `u`) JOIN `venta_tickets`.`eventos` `e`) JOIN
    `venta_tickets`.`categorias` `c`)
  WHERE ((`v`.`sec_id` = `s`.`sec_id`) AND (`v`.`usu_id` = `u`.`usu_id`) AND (`s`.`eve_id` = `e`.`eve_id`) AND
         (`e`.`cat_id` = `c`.`cat_id`));
